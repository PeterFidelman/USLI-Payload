/* Xbee.cpp - Library for interfacing with XBee-PRO XSC RF Module
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#include "Arduino.h"
#include "Xbee.h"

Xbee::Xbee() {
}
