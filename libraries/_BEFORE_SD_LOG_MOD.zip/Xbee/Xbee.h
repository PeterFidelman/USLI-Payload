/* Xbee.h - Library for interfacing with XBee-PRO XSC RF Module
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#ifndef Xbee_h
#define Xbee_h

#include "Arduino.h"

class Xbee {
    public:
        Xbee();
    private:
};

#endif
