/* TempHumidity.h - Library for interfacing with Maxdetect RHT03
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#ifndef TempHumidity_h
#define TempHumidity_h

#include "Arduino.h"

class TempHumidity {
    public:
        TempHumidity();
    private:
};

#endif
