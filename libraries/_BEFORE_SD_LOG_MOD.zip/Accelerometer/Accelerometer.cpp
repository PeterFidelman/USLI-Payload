/* Accelerometer.cpp - Library for interfacing with BMA180 accelerometer
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#include "Arduino.h"
#include "Accelerometer.h"

Accelerometer::Accelerometer() {
}
