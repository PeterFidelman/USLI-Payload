/* Accelerometer.h - Library for interfacing with BMA180 accelerometer
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#ifndef Accelerometer_h
#define Accelerometer_h

#include "Arduino.h"

class Accelerometer {
    public:
        Accelerometer();
    private:
};

#endif
