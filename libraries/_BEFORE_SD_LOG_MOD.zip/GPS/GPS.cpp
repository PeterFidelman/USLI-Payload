/* GPS.h - Library for interfacing with Locosys LS2003x-series GPS receiver
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#include "Arduino.h"
#include "GPS.h"

GPS::GPS() {
}
