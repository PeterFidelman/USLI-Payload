/* Camera.cpp - Library for interfacing with LinkSprite LS-Y201 JPEG camera
 * Created by the University of Washington USLI Team, 2010-2011
 * Released into the public domain - use at your own risk!
 */

#include "Arduino.h"
#include "Camera.h"

Camera::Camera() {
}
